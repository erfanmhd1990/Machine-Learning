#import numpy as np
#from matplotlib import pyplot as plt
from bs4 import BeautifulSoup
#from sklearn.model_selection import train_test_split
#from sklearn.datasets import load_iris
#from sklearn.tree import DecisionTreeClassifier
#from sklearn import tree
#from sklearn.tree import DecisionTreeClassifier
import DecisionTree
import time
import mysql.connector
import re
from bs4 import BeautifulSoup
import requests
import json


Ydatabase=input('plz enter database name: ')
Yuser=input('plz enter user : ')
ypass=input('plz enter password : ')
cnx = mysql.connector.connect(user=Yuser, password=ypass,host='127.0.0.1',database=Ydatabase)
cursor=cnx.cursor()



countPages=1
while countPages<50:
	countPages+=1
	intstr=str(countPages)
	str1=('https://www.truecar.com/used-cars-for-sale/listings/?page=1&priceRating[]=fair')
	res=re.sub(r'(\d+)',intstr,str1)
	r2=requests.get(res)
	soup2=BeautifulSoup(r2.text,'html.parser')
	val2=soup2.find_all('li', attrs={'class': 'margin-top-3 d-flex flex-grow col-md-6 col-xl-4'})
	for tag2 in val2:
		#time
		time_object=time.localtime()
		local_time=time.strftime('%Y-%m-%d|%H:%M:%S',time_object)
		#carname
		#model
		valcarname=tag2.find('span', attrs={'class': 'vehicle-header-make-model text-truncate'})
		carnamemodel=valcarname.text.split()
		carname=(carnamemodel[0])
		model=(carnamemodel[1])
		#year
		valyear=tag2.find('span', attrs={'class': 'vehicle-card-year font-size-1'})
		year1=valyear.text.split()
		year=(year1[0])
		#mile
		valm2=tag2.find('div', attrs={'class': 'd-flex w-100 justify-content-between'})
		sm2=valm2.text.split()

		if len(sm2)<=2:
			smm2=sm2[0]
		else:
			smm2="-unknown"
		mile=smm2
		print(mile)
		#color
		valcolor=tag2.find('div', attrs={'data-test': 'vehicleCardColors'})
		color2=valcolor.text.split()
		color=(color2[0])
		#accident
		valaccident=tag2.find('div', attrs={'data-test': 'vehicleCardCondition'})
		valaccident2=valaccident.text.split()
		isaccident=valaccident2[0]
		accident=(valaccident2[0])

		#price
		valp2=tag2.find('div', attrs={'data-test': 'vehicleCardPricingBlockPrice'})
		sp2=valp2.text.split()
		listcarp2=list(sp2)
		price=(sp2[0])
		insert_stmt = ("INSERT INTO ucp1 (local_time, carname, model,year,mile,color,accident,price) " "VALUES (%s, %s, %s,%s, %s, %s,%s, %s)")
		data = (local_time, carname, model,year,mile,color,accident,price)

		cursor.execute(insert_stmt, data)
		cnx.commit()
		if countPages==50:
			break
	if countPages>49:
		break
cnx.close()









