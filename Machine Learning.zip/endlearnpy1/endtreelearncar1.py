import mysql.connector
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier 
#import pandas as pd
#from sklearn.tree import DecisionTreeClassifier
#from sklearn.model_selection import train_test_split
#from sklearn.datasets import load_iris
#from sklearn.tree import DecisionTreeClassifier
#from sklearn import tree
#from sklearn.datasets import load_iris
Ydatabase=input('plz enter database name: ')
Yuser=input('plz enter user : ')
ypass=input('plz enter password : ')
cnx = mysql.connector.connect(user=Yuser, password=ypass,host='127.0.0.1',database=Ydatabase)
cursor=cnx.cursor()
query='SELECT * FROM ucp1 ;'
cursor.execute(query)
x=[]
y=[]
for (local_time, carname, model,year,mile,color,accident,price) in cursor:
    #print('%s,%s,%s,%s,%s,%s,%s,%s' % (local_time, carname, model,year,mile,color,accident,price))
    l=[local_time, carname, model,year,mile,color,accident,price]
    x.append(l[1:7])
    y.append(l[7])


clf=tree.DecisionTreeClassifier()
clf=clf.fit(x,y)
#new_data=[]
#new_data=['ford','Explorer','2018','17,120','White','No']

yourcarname=input('enter car name: ' )
yourcarmodel=input('enter model: ' )
yourcaryear=input('enter year: ' )
yourmile=input('enter miles: ' )
yourcolor=input('enter color: ' )
isaccident=input('is accident? (No,1,2,...) : ' )

new_data=[yourcarname,yourcarmodel,yourcaryear,yourmile,yourcolor,isaccident]

answer=clf.predict(new_data)
print(answer[0])

cnx.close()
